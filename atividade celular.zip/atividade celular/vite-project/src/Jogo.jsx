import { useState } from 'react';

function Jogo() {
  const [resposta, setResposta] = useState('');
  const [numero1, setNumero1] = useState(0);
  const [numero2, setNumero2] = useState(0);
  const [operador, setOperador] = useState('');
  const [pontos, setPontos] = useState(0);

  // Função para gerar os números aleatórios e o operador
  const gerarDesafio = () => {
    const num1 = Math.floor(Math.random() * 100); // Gera um número entre 0 e 100
    const num2 = Math.floor(Math.random() * 100); // Gera outro número entre 0 e 100
    const operadores = ['+', '-', '*', '/'];
    const operadorEscolhido = operadores[Math.floor(Math.random() * operadores.length)];
    setNumero1(num1);
    setNumero2(num2);
    setOperador(operadorEscolhido);
  };

  // Função para validar a resposta
  const validarResposta = () => {
    let resultado;
    switch (operador) {
      case '+':
        resultado = numero1 + numero2;
        break;
      case '-':
        resultado = numero1 - numero2;
        break;
      case '*':
        resultado = numero1 * numero2;
        break;
      case '/':
        resultado = numero1 / numero2;
        break;
      default:
        return;
    }

    if (parseFloat(resposta) === resultado) {
      setPontos(pontos + 10); // Adiciona 10 pontos em caso de acerto
    } else {
      setPontos(0); // Zera os pontos em caso de erro
    }

    setResposta('');
    gerarDesafio(); // Gera um novo desafio
  };

  // Função para reiniciar o jogo
  const reiniciarJogo = () => {
    setPontos(0);
    setResposta('');
    gerarDesafio();
  };

  return (
    <div className="jogo">
      <h2>Você tem {pontos} pontos</h2>
      <button className="sortear" onClick={gerarDesafio}>Sortear Desafio</button>
      <div className="calculo">
        Quanto é: <span>{numero1} {operador} {numero2}</span>
      </div>
      <input type="text" value={resposta} onChange={(e) => setResposta(e.target.value)} />
      <button className="validar" onClick={validarResposta}>Validar</button>
      <button className="novo" onClick={reiniciarJogo}>Novo Jogo</button>
    </div>
  );
}

export default Jogo;

