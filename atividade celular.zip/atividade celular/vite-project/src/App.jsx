import { useState } from 'react';
import Topo from './Topo.jsx';
import Artigos from './Artigos.jsx';
import Jogo from './Jogo.jsx';
import './App.css';

function App() {
  return (
    <div className="container">
      <div className="content">
        <Topo />
        <Artigos />
      </div>
      <div className="jogo-container">
        <Jogo />
      </div>
    </div>
  );
}

export default App;



