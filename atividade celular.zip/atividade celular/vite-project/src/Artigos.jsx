function Artigos() {
    return (
      <div className="artigos">
        <article>
          <img src="/Estudo.jpg" alt="Criança estudando" />
          <h2>Para ser muito bom amanhã é preciso começar a praticar hoje</h2>
          <p>Prof. Cleiton - 24 Fev 25 - 16:40</p>
          <p>São nos primeiros anos escolares que as crianças aprendem os fundamentos da matemática...</p>
        </article>
        <article>
          <h2>Matemática: O Alicerce para o Sucesso Escolar!</h2>
          <p>Prof. Cleiton - 24 Fev 25 - 16:40</p>
          <p>Nos primeiros anos escolares, as crianças constroem a base do raciocínio lógico...</p>
        </article>
      </div>
    );
  }
  export default Artigos;