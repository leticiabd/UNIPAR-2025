function Topo() {
  return (
    <header className="cabecalho">
      <h1>📖 Calcular</h1>
      <span>Ferramenta de aprendizagem de cálculo</span>
      <span className="data">07/06/2022</span>
    </header>
  );
}
export default Topo;
  