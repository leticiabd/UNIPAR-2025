import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, Typography, Avatar, Box } from '@mui/material';

export default function UserCard({ user }) {
    return (
        <Card>
            <CardContent>
                <Box 
                    textAlign="center"
                    sx={{
                        minWidth: "200px"
                    }}
                >
                    <Avatar
                        src={user.picture.medium}
                        alt={`${user.name.first} ${user.name.last}`}
                        sx={{
                            width: 80,
                            height: 80,
                            margin: "0 auto"
                        }}
                    />

                    <Typography 
                        variant="h6"
                        color='text.primary'
                        component="div"
                        sx={{
                            marginTop: 2
                        }}    
                    >
                        {user.name.first} {user.name.last}
                    </Typography>

                    <Typography 
                        variant="body2" 
                        component="div"
                        color='text.secondary'
                        sx={{
                            marginTop: 2
                        }}    
                    >
                        {user.email}
                    </Typography>

                    <Link
                        to={`/details/${user.email}`}
                    >
                        <Typography
                            variant='body2'
                            color='primary'    
                        >
                            Ver Detalhes
                        </Typography>
                    </Link>
                </Box>
            </CardContent>
        </Card>
    );
}
